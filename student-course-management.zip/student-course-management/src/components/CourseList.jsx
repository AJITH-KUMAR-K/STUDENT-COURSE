import React, { useEffect, useState } from 'react';

const CourseList = () => {
    const [courses, setCourses] = useState([]); 
    const [newCourse, setNewCourse] = useState(''); 

    useEffect(() => {
        fetch('/api/courses')
            .then(response => response.json())
            .then(data => setCourses(data)); 
    }, []);

    const addCourse = (e) => {
        e.preventDefault(); 
        fetch('/api/courses', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: newCourse }), 
        })
            .then(response => response.json())
            .then(data => {
                setCourses([...courses, data]); 
                setNewCourse(''); 
            });
    };

    return (
        <div>
            <h2>Course List</h2>
            <ul>
                {courses.map(course => (
                    <li key={course.id}>{course.name}</li> 
                ))}
            </ul>
            <form onSubmit={addCourse}>
                <input
                    type="text"
                    value={newCourse}
                    onChange={(e) => setNewCourse(e.target.value)} 
                    placeholder="Add new course"
                    required
                />
                <button type="submit">Add Course</button>
            </form>
        </div>
    );
};

export default CourseList;
