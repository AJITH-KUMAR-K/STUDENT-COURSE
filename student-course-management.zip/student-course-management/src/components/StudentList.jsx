import React, { useEffect, useState } from 'react';

const StudentList = () => {
    const [students, setStudents] = useState([]); 
    const [newStudent, setNewStudent] = useState('');

    useEffect(() => {
        fetch('/api/students')
            .then(response => response.json())
            .then(data => setStudents(data))
            .catch(error => console.error('Error fetching students:', error)); // Error handling for fetching
    }, []);

    const addStudent = (e) => {
        e.preventDefault(); 
        fetch('/api/students', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: newStudent }), 
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                setStudents([...students, data]); 
                setNewStudent(''); 
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
                // Optionally, you can show an error message to the user here
            });
    };

    return (
        <div>
            <h2>Student List</h2>
            <ul>
                {students.map(student => (
                    <li key={student.id}>{student.name}</li> 
                ))}
            </ul>
            <form onSubmit={addStudent}>
                <input
                    type="text"
                    value={newStudent}
                    onChange={(e) => setNewStudent(e.target.value)} 
                    placeholder="Add new student"
                    required
                />
                <button type="submit">Add Student</button>
            </form>
        </div>
    );
};

export default StudentList;
