import React from 'react';
import './components/student.css'
import './enrollment.css'

import StudentList from './components/StudentList';
import CourseList from './components/CourseList';
import EnrollmentComponent from './components/EnrollmentComponent';

const App = () => {
    return (
        <div>
            <h1>Student Course Management</h1>
            <StudentList />
            <CourseList />
            <EnrollmentComponent />
        </div>
    );
};

export default App;
