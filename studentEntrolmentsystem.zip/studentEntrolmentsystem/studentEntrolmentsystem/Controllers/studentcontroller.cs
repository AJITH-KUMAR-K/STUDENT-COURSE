﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using studentEntrolmentsystem.Data;
using studentEntrolmentsystem.Models;

namespace studentEntrolmentsystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class studentcontroller : ControllerBase
    {

        private readonly Applicationdbcontext dbContext;

        public studentcontroller(Applicationdbcontext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult GetAllstudents()
        {
            var students = dbContext.student.ToList();
            return Ok(students);
        }

        [HttpPost]
        public IActionResult AddEmployee(student addstudent)
        {
            var studententity = new student()
            {
                Name = addstudent.Name,

                Email = addstudent.Email


            };
            dbContext.student.Add(studententity);
            dbContext.SaveChanges();
            return Ok(studententity);
        }
    }
}
